#ifndef ZVGINTRF_H
#define ZVGINTRF_H

int zvg_open(void);
void zvg_close(void);

#endif
