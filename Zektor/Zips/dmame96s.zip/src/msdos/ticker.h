extern void init_ticker(void);

