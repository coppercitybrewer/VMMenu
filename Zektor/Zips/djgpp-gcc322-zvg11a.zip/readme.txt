put these files in a temporary directory on your hard disk ( i.e. c:\download ):

install.bat
seal107p.zip
zvg_sdk11p.zip
ftp://ftp.info-zip.org/pub/infozip/MSDOS/unz550x.exe
ftp://ftp.info-zip.org/pub/infozip/WIN32/unz550xN.exe
http://clio.rice.edu/cwsdpmi/csdpmi5b.zip
http://clio.rice.edu/djgpp/win2k/djdev204_pre_alpha.zip
http://clio.rice.edu/djgpp/win2k/bnu213b.zip
http://clio.rice.edu/djgpp/win2k/dif28b.zip

http://clio.rice.edu/djgpp/win2k/fil41b.zip
http://clio.rice.edu/djgpp/win2k/gcc322b.zip
http://clio.rice.edu/djgpp/win2k/mak380b.zip
http://clio.rice.edu/djgpp/win2k/pat253b.zip
http://upx.sourceforge.net/download/upx124d.zip
http://upx.sourceforge.net/download/upx124w.zip
http://easynews.dl.sourceforge.net/sourceforge/nasm/nasm-0.98.35-win32.zip
http://easynews.dl.sourceforge.net/sourceforge/nasm/nasm-0.98.35-djgpp.zip
http://easynews.dl.sourceforge.net/sourceforge/alleg/all419.zip
http://easynews.dl.sourceforge.net/sourceforge/libpng/zlib114.zip
http://files1.sonicspot.com/sealsdk/seal107.zip
http://www.zektor.com/zvg/downloads/zvg_sdk11a.zip

then execute install.bat

links:
http://www.info-zip.org/
http://clio.rice.edu/cwsdpmi/
http://clio.rice.edu/djgpp/win2k/main_204.htm
http://upx.sourceforge.net/
http://alleg.sourceforge.net/
http://nasm.sourceforge.net/
http://www.gzip.org/zlib/
http://www.sonicspot.com/sealsdk/sealsdk.html
http://www.zektor.com/zvg/zvg_download.htm

